import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Send, Clock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import AnimatedSection from '../components/shared/AnimatedSection';
import GlassCard from '../components/shared/GlassCard';
import { toast } from 'sonner';

const contactInfo = [
  { icon: MapPin, label: 'Address', value: 'Property Investment Office 4, Dubai Investment Park First, Office S-200, Dubai - UAE' },
  { icon: Phone, label: 'Phone', value: '+971 56 568 8566', href: 'tel:+971565688566' },
  { icon: Mail, label: 'Email', value: 'Info@almersalalsareeuae.com', href: 'mailto:Info@almersalalsareeuae.com' }, // Changed working hours as per request
  { icon: Clock, label: 'Working Hours', value: 'Monday - Saturday: 11:00 AM - 11:00 PM (GST)' },
];

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', company: '', message: '' });
  const [sending, setSending] = useState(false);

  const handleSubmit = async (/** @type {React.FormEvent<HTMLFormElement>} */ e) => {
    e.preventDefault();
    setSending(true);
    // Simulate submission
    await new Promise(r => setTimeout(r, 1500));
    toast.success('Message sent successfully! We will contact you shortly.');
    setForm({ name: '', email: '', phone: '', company: '', message: '' });
    setSending(false);
  };

  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-24 sm:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-navy/50 to-navy-deep" />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <span className="text-gold font-mono text-xs tracking-[0.3em] uppercase mb-4 block">Get in Touch</span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold gold-gradient-text mb-4">
              Contact Us
            </h1>
            <p className="text-gold-light text-lg max-w-xl mx-auto">
              Ready to start a wholesale partnership? Reach out to our team today
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Info */}
            <div className="lg:col-span-2 space-y-6">
              <AnimatedSection>
                <h2 className="text-2xl font-bold gold-gradient-text mb-2">
                  ALMERSAL ALSAREE ELECTRONIS TRADING L.L.C
                </h2>
                <div className="w-16 h-px bg-gold/30 mb-8" />
              </AnimatedSection>

              {contactInfo.map((item, i) => (
                <AnimatedSection key={item.label} delay={i * 0.1}>
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-gold/10 rounded-lg flex-shrink-0">
                      <item.icon className="w-5 h-5 text-gold" />
                    </div>
                    <div>
                      <span className="text-gold font-mono text-xs tracking-wider uppercase block mb-1">
                        {item.label}
                      </span>
                      {item.href ? (
                        <a href={item.href} className="text-black/70 hover:text-gold transition-colors break-all">
                          {item.value}
                        </a>
                      ) : (
                        <p className="text-black/70">{item.value}</p>
                      )}
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>

            {/* Form */}
            <AnimatedSection delay={0.2} className="lg:col-span-3">
              <GlassCard className="p-8 sm:p-10">
                <h3 className="text-xl font-bold text-black mb-6">Send Us a Message</h3>
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-gold font-mono text-xs tracking-wider uppercase block mb-2">Name *</label>
                      <Input
                        required
                        value={form.name}
                        onChange={(/** @type {React.ChangeEvent<HTMLInputElement>} */ e) => setForm({ ...form, name: e.target.value })}
                        className="bg-navy/50 border-gold/20 text-black focus:border-gold focus:ring-gold/20 placeholder:text-black/20"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label className="text-gold font-mono text-xs tracking-wider uppercase block mb-2">Email *</label>
                      <Input
                        required
                        type="email"
                        value={form.email}
                        onChange={(/** @type {React.ChangeEvent<HTMLInputElement>} */ e) => setForm({ ...form, email: e.target.value })}
                        className="bg-navy/50 border-gold/20 text-black focus:border-gold focus:ring-gold/20 placeholder:text-black/20"
                        placeholder="you@company.com"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-gold font-mono text-xs tracking-wider uppercase block mb-2">Phone</label>
                      <Input
                        value={form.phone}
                        onChange={(/** @type {React.ChangeEvent<HTMLInputElement>} */ e) => setForm({ ...form, phone: e.target.value })}
                        className="bg-navy/50 border-gold/20 text-black focus:border-gold focus:ring-gold/20 placeholder:text-black/20"
                        placeholder="+1 234 567 890"
                      />
                    </div>
                    <div>
                      <label className="text-gold font-mono text-xs tracking-wider uppercase block mb-2">Company</label>
                      <Input
                        value={form.company}
                        onChange={(/** @type {React.ChangeEvent<HTMLInputElement>} */ e) => setForm({ ...form, company: e.target.value })}
                        className="bg-navy/50 border-gold/20 text-black focus:border-gold focus:ring-gold/20 placeholder:text-black/20"
                        placeholder="Company name"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-gold font-mono text-xs tracking-wider uppercase block mb-2">Message *</label>
                    <Textarea
                      required
                      value={form.message}
                      onChange={(/** @type {React.ChangeEvent<HTMLTextAreaElement>} */ e) => setForm({ ...form, message: e.target.value })}
                      rows={5}
                      className="bg-navy/50 border-gold/20 text-black focus:border-gold focus:ring-gold/20 placeholder:text-black/20 resize-none"
                      placeholder="Tell us about your wholesale requirements..."
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={sending}
                    className="w-full sm:w-auto liquid-btn bg-transparent border border-gold text-gold hover:text-navy-deep font-medium tracking-wider uppercase text-sm px-8 py-5 rounded-sm"
                  >
                    {sending ? (
                      <span className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-gold/30 border-t-gold rounded-full animate-spin" />
                        Sending...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Send className="w-4 h-4" />
                        Send Message
                      </span>
                    )}
                  </Button>
                </form>
              </GlassCard>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Map */}
      <section className="py-12 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <GlassCard className="p-2 overflow-hidden">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3614.145!2d55.155!3d25.005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjXCsDAwJzE4LjAiTiA1NcKwMDknMTguMCJF!5e0!3m2!1sen!2sae!4v1700000000000!5m2!1sen!2sae"
                width="100%"
                height="400"
                style={{ border: 0, borderRadius: '0.5rem', filter: 'invert(90%) hue-rotate(180deg) contrast(0.9)' }}
                allowFullScreen
                loading="lazy"
                title="Office Location"
              />
            </GlassCard>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
}